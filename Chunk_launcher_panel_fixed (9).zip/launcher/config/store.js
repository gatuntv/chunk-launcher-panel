const Store = require('electron-store');

// Todo lo que el launcher necesita recordar entre sesiones:
// - la cuenta activa (Microsoft o cracked)
// - el caché de tokens de Microsoft (lo maneja prismarine-auth internamente en su propia carpeta)
// - las instancias ya sincronizadas desde el panel
// - las skins que el usuario ha guardado localmente
const store = new Store({
  name: 'launcher-config',
  defaults: {
    account: null,       // { type: 'microsoft'|'cracked', uuid, name, headUrl, skinUrl }
    instances: [],        // [{ id, name, iconUrl, backgroundUrl, tag, version, loader, modsUrl }]
    skins: {}              // { [uuid]: [{ id, name, url, previewUrl, active }] }
  }
});

module.exports = store;
