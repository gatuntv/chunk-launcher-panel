var { ipcRenderer } = require('electron');

const loginFooter = document.getElementById('loginFooter');
ipcRenderer.invoke('app:get-version').then((v) => {
  if (loginFooter) loginFooter.textContent = `Chunk Launcher v${v}`;
});

const msLoginBtn = document.getElementById('msLoginBtn');
const showCrackedBtn = document.getElementById('showCrackedBtn');
const crackedForm = document.getElementById('crackedForm');
const crackedUsername = document.getElementById('crackedUsername');
const crackedLoginBtn = document.getElementById('crackedLoginBtn');
const statusMsg = document.getElementById('statusMsg');
const deviceCodeBox = document.getElementById('deviceCodeBox');
const deviceUrl = document.getElementById('deviceUrl');
const deviceCode = document.getElementById('deviceCode');
const copyCodeBtn = document.getElementById('copyCodeBtn');
const deviceCodeExpiry = document.getElementById('deviceCodeExpiry');
const deviceCodeHint = document.getElementById('deviceCodeHint');

let countdownTimer = null;

function stopCountdown() {
  if (countdownTimer) clearInterval(countdownTimer);
  countdownTimer = null;
}

function startCountdown(seconds) {
  stopCountdown();
  let remaining = seconds;
  const render = () => {
    const m = Math.floor(remaining / 60);
    const s = String(remaining % 60).padStart(2, '0');
    deviceCodeExpiry.textContent = remaining > 0
      ? `Expira en ${m}:${s}`
      : 'El código expiró, esperando uno nuevo…';
  };
  render();
  countdownTimer = setInterval(() => {
    remaining -= 1;
    if (remaining < 0) { stopCountdown(); return; }
    render();
  }, 1000);
}

// Si el usuario hace click en el link de verificación, lo abrimos en su
// navegador de verdad; si no, el link navegaría la propia ventana del
// launcher hacia esa URL y la app quedaría "rota" mostrando la web de MS.
deviceUrl.addEventListener('click', (e) => {
  e.preventDefault();
  require('electron').shell.openExternal(deviceUrl.href);
});

// --- Login con Microsoft (flujo "device code") ---
msLoginBtn.addEventListener('click', () => {
  statusMsg.textContent = 'Abriendo autenticación de Microsoft…';
  ipcRenderer.send('auth:ms-login-start');
});

// El proceso principal nos avisa el código que el usuario debe introducir.
// data.attempt > 1 significa que prismarine-auth reintentó el flujo completo
// (típico si la cuenta no tiene Xbox Live / Minecraft asociado) y generó un
// código nuevo — antes esto pasaba en silencio y parecía que el código
// "cambiaba solo" sin que el usuario entendiera por qué.
ipcRenderer.on('auth:device-code', (_e, data) => {
  deviceCodeBox.style.display = 'flex';
  deviceUrl.textContent = data.verificationUri;
  deviceUrl.href = data.verificationUri;
  deviceCode.textContent = data.userCode;
  copyCodeBtn.textContent = 'Copiar';
  copyCodeBtn.classList.remove('copied');
  startCountdown(data.expiresIn || 900);

  if (data.attempt > 1) {
    statusMsg.textContent = `Reintentando autenticación… (intento ${data.attempt}), se generó un código nuevo`;
  } else {
    statusMsg.textContent = 'Esperando confirmación…';
  }

  // Después de un par de reintentos, lo más probable es que sea un problema
  // de la cuenta (sin Xbox Live / sin Minecraft comprado) y no algo que el
  // usuario pueda arreglar reescribiendo el código más rápido.
  deviceCodeHint.style.display = data.attempt >= 3 ? 'block' : 'none';
});

copyCodeBtn.addEventListener('click', () => {
  const code = deviceCode.textContent.trim();
  if (!code) return;
  navigator.clipboard.writeText(code).then(() => {
    copyCodeBtn.textContent = '¡Copiado!';
    copyCodeBtn.classList.add('copied');
  }).catch(() => {
    copyCodeBtn.textContent = 'No se pudo copiar';
  });
});

ipcRenderer.on('auth:ms-login-success', (_e, profile) => {
  stopCountdown();
  statusMsg.textContent = `¡Bienvenido, ${profile.name}!`;
  setTimeout(() => ipcRenderer.send('nav:go-main'), 600);
});

ipcRenderer.on('auth:ms-login-error', (_e, message) => {
  stopCountdown();
  statusMsg.textContent = `Error: ${message}`;
  deviceCodeBox.style.display = 'none';
  deviceCodeHint.style.display = 'none';
});

// --- Login "cracked" (solo username, sin verificación real de Mojang) ---
showCrackedBtn.addEventListener('click', () => {
  const isOpen = crackedForm.style.display === 'flex';
  crackedForm.style.display = isOpen ? 'none' : 'flex';
  if (!isOpen) crackedUsername.focus();
});

function submitCrackedLogin() {
  const name = crackedUsername.value.trim();
  if (!/^[a-zA-Z0-9_]{3,16}$/.test(name)) {
    statusMsg.textContent = 'Nombre inválido: usa 3 a 16 letras, números o guion bajo, sin espacios.';
    statusMsg.style.color = '#e06666';
    return;
  }
  statusMsg.style.color = '';
  statusMsg.textContent = 'Entrando…';
  crackedLoginBtn.disabled = true;
  ipcRenderer.send('auth:cracked-login', name);
}

crackedLoginBtn.addEventListener('click', submitCrackedLogin);

// Enter también envía el formulario
crackedUsername.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') submitCrackedLogin();
});

ipcRenderer.on('auth:cracked-login-success', () => {
  ipcRenderer.send('nav:go-main');
});

// Antes no existía este manejador: si algo fallaba en el proceso principal,
// el botón se quedaba en "Entrando…" para siempre sin ningún aviso.
ipcRenderer.on('auth:cracked-login-error', (_e, message) => {
  crackedLoginBtn.disabled = false;
  statusMsg.style.color = '#e06666';
  statusMsg.textContent = `Error: ${message}`;
});
