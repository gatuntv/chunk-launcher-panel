var { ipcRenderer } = require('electron');

let viewer;
let currentAccount = null;
let savedSkins = []; // [{id, name, url, active}]

async function init() {
  currentAccount = await ipcRenderer.invoke('account:get-active');
  document.getElementById('usernameTag').textContent = currentAccount?.name || 'Usuario';

  viewer = new skinview3d.SkinViewer({
    canvas: document.getElementById('skinCanvas'),
    width: 260,
    height: 340,
    // UUID real de la skin "Steve" clásica, usado como valor por defecto
    skin: currentAccount?.skinUrl || 'https://crafatar.com/skins/8667ba71-b85a-4004-af54-457a9734eed7'
  });
  viewer.controls.enableZoom = false;
  viewer.animation = new skinview3d.WalkingAnimation();

  savedSkins = await ipcRenderer.invoke('skins:list', currentAccount?.uuid);
  renderSkinGrid();
}

async function renderSkinGrid() {
  const grid = document.getElementById('skinGrid');
  // limpia todo menos el slot de "añadir"
  [...grid.querySelectorAll('.skin-slot:not(.add-slot)')].forEach(el => el.remove());

  for (const skin of savedSkins) {
    const slot = document.createElement('div');
    slot.className = 'skin-slot' + (skin.active ? ' selected' : '');

    // Antes se mostraba la textura completa (64x64) estirada, lo que se veía
    // como un patrón raro y en blanco y negro. Ahora recortamos solo la cabeza,
    // en color normal, sin ningún filtro.
    try {
      const headThumb = await renderHeadFromSkin(skin.url);
      slot.innerHTML = `<img src="${headThumb}" alt="${skin.name}" />`;
    } catch {
      slot.innerHTML = `<img src="${skin.url}" alt="${skin.name}" />`;
    }

    slot.addEventListener('click', () => selectSkin(skin));
    grid.appendChild(slot);
  }
}

async function selectSkin(skin) {
  // Actualiza el visor 3D al instante
  viewer.loadSkin(skin.url);
  savedSkins.forEach(s => (s.active = s.id === skin.id));
  renderSkinGrid();

  // Genera el ícono de cabeza (en color normal) para el botón de cuenta del menú principal
  const headUrl = await renderHeadFromSkin(skin.url);

  // Sube la skin a la cuenta de Mojang/Microsoft (si está logueado con MS)
  const result = await ipcRenderer.invoke('skins:apply', { uuid: currentAccount.uuid, skin, headUrl });
  if (result?.success) {
    ipcRenderer.send('account:skin-updated', result.headUrl);
  }
}

document.getElementById('editSkinBtn').addEventListener('click', () => {
  document.getElementById('skinFileInput').click();
});

document.getElementById('addSkinSlot').addEventListener('click', () => {
  document.getElementById('skinFileInput').click();
});

document.getElementById('skinFileInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const arrayBuffer = await file.arrayBuffer();
  const result = await ipcRenderer.invoke('skins:upload', {
    uuid: currentAccount.uuid,
    fileName: file.name,
    buffer: Buffer.from(arrayBuffer)
  });
  if (result?.success) {
    savedSkins = await ipcRenderer.invoke('skins:list', currentAccount.uuid);
    renderSkinGrid();
  }
});

init();
