var { ipcRenderer } = require('electron');

document.getElementById('tbMinimize')?.addEventListener('click', () => ipcRenderer.send('window:minimize'));
document.getElementById('tbMaximize')?.addEventListener('click', () => ipcRenderer.send('window:maximize'));
document.getElementById('tbClose')?.addEventListener('click', () => ipcRenderer.send('window:close'));
document.getElementById('tbBack')?.addEventListener('click', () => ipcRenderer.send('nav:go-main'));

// --- Menú del launcher (botón de actualizar) ---
const tbMenu = document.getElementById('tbMenu');
const tbDropdown = document.getElementById('tbDropdown');
const checkUpdateBtn = document.getElementById('checkUpdateBtn');
const appVersionEl = document.getElementById('appVersion');

if (tbMenu && tbDropdown) {
  ipcRenderer.invoke('app:get-version').then((v) => {
    if (appVersionEl) appVersionEl.textContent = `v${v}`;
  });

  tbMenu.addEventListener('click', (e) => {
    e.stopPropagation();
    tbDropdown.hidden = !tbDropdown.hidden;
  });

  document.addEventListener('click', (e) => {
    if (!tbDropdown.hidden && !tbDropdown.contains(e.target) && e.target !== tbMenu) {
      tbDropdown.hidden = true;
    }
  });

  checkUpdateBtn?.addEventListener('click', async () => {
    checkUpdateBtn.disabled = true;
    checkUpdateBtn.innerHTML = '<span class="tb-dropdown-item-icon">&#8635;</span> Buscando…';

    const result = await ipcRenderer.invoke('app:check-update');

    if (result.status === 'update-available') {
      checkUpdateBtn.innerHTML = `<span class="tb-dropdown-item-icon">&#8635;</span> Nueva versión ${result.latest} disponible`;
      checkUpdateBtn.onclick = () => ipcRenderer.send('app:open-download', result.url);
      checkUpdateBtn.disabled = false;
    } else if (result.status === 'up-to-date') {
      checkUpdateBtn.innerHTML = '<span class="tb-dropdown-item-icon">&#10003;</span> Estás al día';
      setTimeout(() => {
        checkUpdateBtn.innerHTML = '<span class="tb-dropdown-item-icon">&#8635;</span> Buscar actualizaciones';
        checkUpdateBtn.disabled = false;
      }, 2500);
    } else {
      checkUpdateBtn.innerHTML = '<span class="tb-dropdown-item-icon">&#33;</span> No se pudo comprobar';
      setTimeout(() => {
        checkUpdateBtn.innerHTML = '<span class="tb-dropdown-item-icon">&#8635;</span> Buscar actualizaciones';
        checkUpdateBtn.disabled = false;
      }, 2500);
    }
  });
}

// --- Modal de confirmación genérico (reemplaza al confirm() nativo, que se
// ve como un cartelito del sistema y no combina con el resto del launcher) ---
function showConfirm(message) {
  const overlay = document.getElementById('confirmOverlay');
  const messageEl = document.getElementById('confirmMessage');
  const acceptBtn = document.getElementById('confirmAcceptBtn');
  const cancelBtn = document.getElementById('confirmCancelBtn');
  if (!overlay) return Promise.resolve(false);

  messageEl.textContent = message;
  overlay.hidden = false;

  return new Promise((resolve) => {
    const cleanup = (result) => {
      overlay.hidden = true;
      acceptBtn.removeEventListener('click', onAccept);
      cancelBtn.removeEventListener('click', onCancel);
      overlay.removeEventListener('click', onOverlay);
      resolve(result);
    };
    const onAccept = () => cleanup(true);
    const onCancel = () => cleanup(false);
    const onOverlay = (e) => { if (e.target === overlay) cleanup(false); };

    acceptBtn.addEventListener('click', onAccept);
    cancelBtn.addEventListener('click', onCancel);
    overlay.addEventListener('click', onOverlay);
  });
}

if (typeof window !== 'undefined') window.showConfirm = showConfirm;
