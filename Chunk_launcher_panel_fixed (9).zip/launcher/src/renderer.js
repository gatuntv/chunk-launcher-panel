var { ipcRenderer } = require('electron');

const instanceList = document.getElementById('instanceList');
const emptyState = document.getElementById('emptyState');
const playBtn = document.getElementById('playBtn');
const progressWrap = document.getElementById('progressWrap');
const progressFill = document.getElementById('progressFill');
const progressLabel = document.getElementById('progressLabel');
const accountHeadImg = document.getElementById('accountHeadImg');
const accountBtn = document.getElementById('accountBtn');
const switchAccountBtn = document.getElementById('switchAccountBtn');
const playingStatus = document.getElementById('playingStatus');
const playingInstanceName = document.getElementById('playingInstanceName');

let instances = [];
let selectedInstance = null;
let isPlaying = false; // hay una instancia corriendo AHORA (sin importar cuál esté seleccionada)

async function loadAccount() {
  const account = await ipcRenderer.invoke('account:get-active');
  if (account?.headUrl) accountHeadImg.src = account.headUrl;
}

// Pinta en pantalla lo que haya actualmente en `instances` (sin volver a pedirlo).
function renderInstances() {
  instanceList.innerHTML = '';

  if (!instances.length) {
    emptyState.hidden = false;
    playBtn.disabled = true;
    return;
  }

  emptyState.hidden = true;

  instances.forEach((inst, idx) => {
    const el = document.createElement('div');
    el.className = 'instance-icon' + (idx === 0 ? ' active' : '');
    el.title = inst.name;
    el.innerHTML = `<img src="${inst.iconUrl}" alt="${inst.name}" />`;
    el.addEventListener('click', () => selectInstance(inst, el));
    instanceList.appendChild(el);
  });

  selectInstance(instances[0], instanceList.firstChild);
}

// Al abrir el launcher: primero muestra lo que ya había guardado localmente,
// y de inmediato pide la lista fresca al panel para que las instancias nuevas
// (o borradas) aparezcan sin que el usuario tenga que tocar nada.
async function loadInstances() {
  instances = await ipcRenderer.invoke('instances:list');
  renderInstances();
  ipcRenderer.send('instances:refresh-from-panel');
}

// Antes esto no existía: el main process avisaba que ya había datos nuevos,
// pero nadie escuchaba, así que la pantalla nunca se actualizaba.
ipcRenderer.on('instances:updated', (_e, updated) => {
  instances = updated;
  renderInstances();
});

function selectInstance(inst, el) {
  selectedInstance = inst;
  [...instanceList.children].forEach(c => c.classList.remove('active'));
  el.classList.add('active');

  document.querySelector('.main').style.backgroundImage = inst.backgroundUrl
    ? `url(${inst.backgroundUrl})`
    : '';
  playBtn.disabled = isPlaying; // si ya hay una instancia jugando, seguimos bloqueados aunque cambies de instancia
}

// --- Descarga + lanzamiento ---
playBtn.addEventListener('click', () => {
  if (!selectedInstance) return;
  playBtn.disabled = true;
  progressWrap.hidden = false;
  progressLabel.style.color = '';
  progressFill.style.width = '0%';
  ipcRenderer.send('game:launch', selectedInstance.id);
});

ipcRenderer.on('game:progress', (_e, { percent, label }) => {
  progressFill.style.width = `${percent}%`;
  progressLabel.textContent = label;
});

ipcRenderer.on('game:launched', (_e, playing) => {
  progressWrap.hidden = true;
  isPlaying = true;
  playBtn.disabled = true;
  if (playing) {
    playingInstanceName.textContent = playing.name;
    playingStatus.hidden = false;
  }
});

ipcRenderer.on('game:closed', () => {
  isPlaying = false;
  playingStatus.hidden = true;
  playBtn.disabled = !selectedInstance;
});

ipcRenderer.on('game:error', (_e, message) => {
  playBtn.disabled = isPlaying;
  progressLabel.style.color = '#e06666';
  progressLabel.textContent = `Error: ${message}`;
});

// --- Navegación ---
accountBtn.addEventListener('click', () => ipcRenderer.send('nav:go-skin-selector'));
switchAccountBtn.addEventListener('click', async () => {
  // Es destructivo (cierra la sesión activa), así que confirmamos antes.
  const confirmed = await window.showConfirm('¿Cerrar sesión y entrar con otra cuenta?');
  if (confirmed) ipcRenderer.send('auth:logout');
});

ipcRenderer.on('account:head-updated', (_e, headUrl) => {
  accountHeadImg.src = headUrl;
});

loadAccount();
loadInstances();
