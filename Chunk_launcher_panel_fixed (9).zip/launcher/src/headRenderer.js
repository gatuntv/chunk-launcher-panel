/**
 * Convierte una textura de skin completa (64x64 o 64x32) en una imagen
 * cuadrada mostrando SOLO la cabeza, en color normal (sin filtros),
 * incluyendo la capa del "hat" (sombrero/pelo) si la skin la trae.
 * Devuelve una Data URL lista para usar en cualquier <img>.
 */
function renderHeadFromSkin(skinUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    // crossOrigin solo hace falta (y solo funciona) para URLs remotas http(s).
    // En skins locales (file://, las que subís vos) ponerlo rompe el canvas
    // ("tainted canvas") y el toDataURL de abajo tira SecurityError — por
    // eso antes se veía la textura cruda en vez de la cara recortada.
    if (/^https?:\/\//i.test(skinUrl)) img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const size = 128; // tamaño final del ícono
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false; // mantiene el estilo "pixel art"

        // La cara base siempre está en el mismo lugar del layout de Minecraft: (8,8) a (16,16)
        ctx.drawImage(img, 8, 8, 8, 8, 0, 0, size, size);

        // La capa exterior de la cabeza (hat) existe en (40,8) a (48,16).
        // En texturas antiguas de 64x32 esa capa no existe, así que la omitimos.
        if (img.height >= 64) {
          ctx.drawImage(img, 40, 8, 8, 8, 0, 0, size, size);
        }

        resolve(canvas.toDataURL('image/png'));
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = reject;
    img.src = skinUrl;
  });
}

if (typeof module !== 'undefined') module.exports = { renderHeadFromSkin };
