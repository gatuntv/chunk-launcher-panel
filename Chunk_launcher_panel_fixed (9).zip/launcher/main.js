const { app, BrowserWindow, ipcMain, shell, clipboard } = require('electron');
const path = require('path');
const fetch = require('node-fetch');
const fs = require('fs');

const store = require('./config/store');
const authManager = require('./auth/authManager');
const { launchInstance } = require('./launcher/gameLauncher');

// URL del panel externo donde se administran las instancias.
// Cambia esto por el dominio real donde despliegues la carpeta /panel.
const PANEL_API_URL = process.env.PANEL_API_URL || 'http://localhost:4000/api/instances';

// Para el botón "Buscar actualizaciones": poné acá tu repo de GitHub
// ("usuario/repo") una vez que lo subas, y comparamos la versión instalada
// contra el último release publicado. Mientras esté vacío, el botón avisa
// que todavía no hay un repo configurado en vez de fallar en silencio.
const UPDATE_REPO = process.env.UPDATE_REPO || '';

let mainWindow;

function createWindow(startPage) {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1000,
    minHeight: 640,
    title: 'Chunk Launcher',
    frame: false, // usamos nuestra propia titlebar (ver style.css)
    backgroundColor: '#000000',
    webPreferences: {
      nodeIntegration: true,      // simplifica el uso de ipcRenderer directamente en los renderers
      contextIsolation: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', startPage));

  // F12 abre las herramientas de desarrollador (consola) para depurar errores
  mainWindow.webContents.on('before-input-event', (_e, input) => {
    if (input.key === 'F12') mainWindow.webContents.toggleDevTools();
  });
}

app.whenReady().then(() => {
  const account = store.get('account');
  // Si no hay cuenta guardada, se pide registro/login en el primer arranque
  createWindow(account ? 'index.html' : 'login.html');
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---------------------------------------------------------------------
// ACTUALIZACIONES
// ---------------------------------------------------------------------
ipcMain.handle('app:get-version', () => app.getVersion());

ipcMain.handle('app:check-update', async () => {
  if (!UPDATE_REPO) {
    return { status: 'error', message: 'No hay un repositorio configurado (UPDATE_REPO)' };
  }
  try {
    const res = await fetch(`https://api.github.com/repos/${UPDATE_REPO}/releases/latest`, {
      headers: { 'User-Agent': 'chunk-launcher' }
    });
    if (!res.ok) return { status: 'error', message: `GitHub respondió ${res.status}` };
    const release = await res.json();
    const latest = (release.tag_name || '').replace(/^v/, '');
    const current = app.getVersion();

    if (latest && latest !== current) {
      return { status: 'update-available', latest, url: release.html_url };
    }
    return { status: 'up-to-date' };
  } catch (err) {
    return { status: 'error', message: err.message };
  }
});

ipcMain.on('app:open-download', (_e, url) => shell.openExternal(url));

// ---------------------------------------------------------------------
// CONTROLES DE VENTANA (la barra de título es personalizada, sin marco nativo)
// ---------------------------------------------------------------------
ipcMain.on('window:minimize', () => mainWindow.minimize());
ipcMain.on('window:maximize', () => {
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.on('window:close', () => mainWindow.close());

// ---------------------------------------------------------------------
// NAVEGACIÓN
// ---------------------------------------------------------------------
ipcMain.on('nav:go-main', () => mainWindow.loadFile(path.join(__dirname, 'src', 'index.html')));
ipcMain.on('nav:go-skin-selector', () => mainWindow.loadFile(path.join(__dirname, 'src', 'skin-selector.html')));

// ---------------------------------------------------------------------
// AUTENTICACIÓN
// ---------------------------------------------------------------------
ipcMain.on('auth:ms-login-start', async (event) => {
  try {
    const account = await authManager.loginWithMicrosoft((deviceCode) => {
      event.sender.send('auth:device-code', deviceCode);
      // Le facilitamos la vida al usuario: le abrimos el navegador directo en
      // la página de verificación y le copiamos el código, así solo tiene
      // que pegar (Ctrl+V) en vez de escribir el código a mano.
      // OJO: authManager nos manda { verificationUri, userCode } (camelCase),
      // no { verification_uri, user_code } — usar el nombre equivocado hacía
      // que esto copiara/abriera "undefined" en silencio (por eso el copiado
      // automático "no funcionaba"). Solo abrimos el navegador en el primer
      // intento; si la librería reintenta, no le abrimos una pestaña nueva
      // cada vez.
      clipboard.writeText(deviceCode.userCode);
      if (deviceCode.attempt === 1) {
        shell.openExternal(deviceCode.verificationUri);
      }
    });
    event.sender.send('auth:ms-login-success', account);
  } catch (err) {
    event.sender.send('auth:ms-login-error', err.message);
  }
});

ipcMain.on('auth:cracked-login', (event, username) => {
  try {
    authManager.loginCracked(username);
    event.sender.send('auth:cracked-login-success');
  } catch (err) {
    console.error('Error en login cracked:', err);
    event.sender.send('auth:cracked-login-error', err.message);
  }
});

ipcMain.handle('account:get-active', () => authManager.getActiveAccount());

ipcMain.on('account:skin-updated', (_e, headUrl) => {
  const account = store.get('account');
  account.headUrl = headUrl;
  store.set('account', account);
  mainWindow.webContents.send('account:head-updated', headUrl);
});

// Cierra la sesión activa (la única que guardamos) y vuelve a la pantalla
// de login para que el usuario pueda entrar con otra cuenta (Microsoft o cracked).
ipcMain.on('auth:logout', () => {
  store.set('account', null);
  mainWindow.loadFile(path.join(__dirname, 'src', 'login.html'));
});

// ---------------------------------------------------------------------
// SKINS
// ---------------------------------------------------------------------
ipcMain.handle('skins:list', (_e, uuid) => {
  const all = store.get('skins');
  return all[uuid] || [];
});

ipcMain.handle('skins:upload', async (_e, { uuid, fileName, buffer }) => {
  const skinsDir = path.join(app.getPath('userData'), 'skins', uuid);
  fs.mkdirSync(skinsDir, { recursive: true });
  const filePath = path.join(skinsDir, `${Date.now()}-${fileName}`);
  fs.writeFileSync(filePath, buffer);

  const all = store.get('skins');
  const list = all[uuid] || [];
  const newSkin = {
    id: `${Date.now()}`,
    name: fileName,
    url: `file://${filePath}`,
    previewUrl: `file://${filePath}`,
    active: false
  };
  list.push(newSkin);
  all[uuid] = list;
  store.set('skins', all);

  return { success: true, skin: newSkin };
});

// Aplica la skin seleccionada: si la cuenta es de Microsoft, la sube al
// perfil real de Minecraft (endpoint oficial de subida de skins); si es
// cracked, solo se aplica localmente para la vista previa.
ipcMain.handle('skins:apply', async (_e, { uuid, skin, headUrl: renderedHeadUrl }) => {
  const account = store.get('account');

  const all = store.get('skins');
  const list = all[uuid] || [];
  list.forEach(s => (s.active = s.id === skin.id));
  all[uuid] = list;
  store.set('skins', all);

  if (account.type === 'microsoft' && account.accessToken) {
    try {
      const form = new (require('form-data'))();
      form.append('variant', 'classic');
      form.append('file', fs.createReadStream(skin.url.replace('file://', '')));

      await fetch('https://api.minecraftservices.com/minecraft/profile/skins', {
        method: 'POST',
        headers: { Authorization: `Bearer ${account.accessToken}`, ...form.getHeaders() },
        body: form
      });
    } catch (err) {
      console.error('No se pudo subir la skin a Mojang:', err.message);
    }
  }

  // Usamos el recorte real de la cabeza (generado en el renderer con canvas),
  // en color normal, en vez de crafatar: crafatar no refleja skins locales
  // que aún no se subieron a Mojang.
  account.headUrl = renderedHeadUrl;
  account.skinUrl = skin.url;
  store.set('account', account);

  return { success: true, headUrl: renderedHeadUrl };
});

// ---------------------------------------------------------------------
// INSTANCIAS (sincronizadas desde el panel externo)
// ---------------------------------------------------------------------
ipcMain.handle('instances:list', () => store.get('instances'));

ipcMain.on('instances:refresh-from-panel', async (event) => {
  try {
    const res = await fetch(PANEL_API_URL);
    const instances = await res.json();
    store.set('instances', instances);
    event.sender.send('instances:updated', instances);
  } catch (err) {
    console.error('No se pudo contactar al panel:', err.message);
  }
});

// ---------------------------------------------------------------------
// LANZAR EL JUEGO
// ---------------------------------------------------------------------
// Guardamos qué instancia está corriendo ahora mismo. Mientras haya una
// activa, no dejamos lanzar otra (Minecraft ya es bastante pesado como para
// tener dos instancias abiertas al mismo tiempo desde el mismo launcher).
let playingInstance = null;

ipcMain.on('game:launch', async (event, instanceId) => {
  if (playingInstance) {
    event.sender.send('game:error', `Ya tenés "${playingInstance.name}" abierto`);
    return;
  }

  try {
    const instances = store.get('instances');
    const instance = instances.find(i => i.id === instanceId);
    const account = authManager.getActiveAccount();

    if (!instance || !account) throw new Error('Falta la instancia o la cuenta activa');

    const launcher = await launchInstance(instance, account, (progress) => {
      event.sender.send('game:progress', progress);
    });

    playingInstance = { id: instance.id, name: instance.name };
    event.sender.send('game:launched', playingInstance);

    // Cuando el proceso de Minecraft se cierra, liberamos el estado para
    // que el botón de Play se vuelva a habilitar y el aviso desaparezca.
    launcher.on('close', () => {
      playingInstance = null;
      event.sender.send('game:closed');
    });
  } catch (err) {
    event.sender.send('game:error', err.message);
  }
});
