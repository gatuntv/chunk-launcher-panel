const path = require('path');
const crypto = require('crypto');
const { Authflow, Titles } = require('prismarine-auth');
const store = require('../config/store');

// Carpeta donde prismarine-auth cachea los tokens de Microsoft/Xbox/Minecraft
// (así el usuario no tiene que volver a iniciar sesión cada vez que abre la app)
const CACHE_DIR = path.join(require('electron').app.getPath('userData'), 'auth-cache');

/**
 * Inicia sesión con una cuenta de Microsoft usando el flujo "device code":
 * a la persona se le muestra un código y una URL (microsoft.com/link), lo introduce
 * en su navegador/teléfono, y aquí recibimos el token de Minecraft ya validado
 * (incluye el chequeo real de que la cuenta posee el juego).
 */
async function loginWithMicrosoft(onDeviceCode) {
  // OJO: Titles.MinecraftJava es el client ID oficial que Mojang usa para el
  // login por "device code" (flow: 'live'), el mismo que usa el launcher
  // oficial. El flow 'msal' es para cuando vos registrás tu propia app en
  // Azure y usás SU client ID — mezclar Titles.MinecraftJava con flow:'msal'
  // hace que Microsoft rechace el login. Por eso nunca terminaba de andar.
  // OJO (fix real): Titles.MinecraftJava + deviceType:'Win32' necesita
  // flow:'sisu', no flow:'live'. La documentación de prismarine-auth lo dice
  // explícito: usar 'live' con ese authTitle tira un error 403 Forbidden al
  // pedir el "title token" de Xbox. 'live' solo funciona sin authTitle (o
  // con el título de Nintendo Switch, que es el que usan la mayoría de
  // launchers "vanilla-like"). Esto era la causa real del 403 que te salió,
  // y probablemente también la causa del código que se regeneraba solo.
  let attempt = 0;
  const flow = new Authflow(
    'launcher-account',       // identificador local de caché, no es el username real
    CACHE_DIR,
    { flow: 'sisu', authTitle: Titles.MinecraftJava, deviceType: 'Win32' },
    (deviceCode) => {
      attempt += 1;
      // prismarine-auth nos entrega { verification_uri, user_code, expires_in, interval, ... }
      onDeviceCode({
        verificationUri: deviceCode.verification_uri,
        userCode: deviceCode.user_code,
        expiresIn: deviceCode.expires_in || 900,
        attempt
      });
    }
  );

  // fetchProfile:true además trae el nombre, uuid y la skin activa desde
  // el perfil real de Minecraft del usuario
  const token = await flow.getMinecraftJavaToken({ fetchProfile: true });

  const profile = token.profile; // { id, name, skins: [{url, state, ...}], capes: [...] }
  const skin = profile?.skins?.find(s => s.state === 'ACTIVE');

  const account = {
    type: 'microsoft',
    uuid: profile.id,
    name: profile.name,
    accessToken: token.token, // token de sesión de Minecraft, se pasa al lanzar el juego
    skinUrl: skin?.url || null,
    headUrl: skin?.url
      ? `https://crafatar.com/avatars/${profile.id}?overlay`
      : `https://crafatar.com/avatars/steve?overlay`
  };

  store.set('account', account);

  // El endpoint de Mojang no solo devuelve la skin activa: también trae las
  // que usaste antes y siguen asociadas a tu cuenta (state: 'INACTIVE'). Antes
  // esas se descartaban acá mismo, así que el "SKINS GUARDADAS" del selector
  // siempre arrancaba vacío aunque la cuenta tuviera varias. Las importamos
  // una sola vez por cuenta (sin pisar las que ya subiste a mano desde el launcher).
  if (profile?.skins?.length) {
    const allSkins = store.get('skins');
    const existing = allSkins[profile.id] || [];
    const existingUrls = new Set(existing.map(s => s.url));

    const imported = profile.skins
      .filter(s => !existingUrls.has(s.url))
      .map((s, i) => ({
        id: s.id || `mojang-${profile.id}-${i}`,
        name: s.state === 'ACTIVE' ? 'Skin actual' : `Skin de tu cuenta ${i + 1}`,
        url: s.url,
        previewUrl: s.url,
        active: s.state === 'ACTIVE'
      }));

    if (imported.length) {
      allSkins[profile.id] = [...existing.map(s => ({ ...s, active: false })), ...imported];
      store.set('skins', allSkins);
    }
  }

  return account;
}

/**
 * Login "cracked": solo se pide un nombre de usuario, sin validar contra Mojang.
 * Se genera un UUID offline (mismo algoritmo que usa Minecraft para cuentas no premium)
 * para que el juego y los mods se comporten de forma consistente.
 */
function loginCracked(username) {
  const offlineUuid = crypto
    .createHash('md5')
    .update(`OfflinePlayer:${username}`)
    .digest('hex')
    .replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');

  const account = {
    type: 'cracked',
    uuid: offlineUuid,
    name: username,
    accessToken: null, // el juego se lanza en modo offline
    skinUrl: null,
    headUrl: `https://crafatar.com/avatars/${offlineUuid}?overlay&default=MHF_Steve`
  };

  store.set('account', account);
  return account;
}

function getActiveAccount() {
  return store.get('account');
}

module.exports = { loginWithMicrosoft, loginCracked, getActiveAccount };
