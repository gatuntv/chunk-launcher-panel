const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const { Client } = require('minecraft-launcher-core');
const { app } = require('electron');

const INSTANCES_ROOT = path.join(app.getPath('userData'), 'instances');
const FABRIC_META = 'https://meta.fabricmc.net/v2/versions/loader';

/**
 * Fabric no viene soportado "de fábrica" en minecraft-launcher-core (a diferencia
 * de Forge, que sí acepta un installer jar). Lo que hacemos es lo mismo que hace
 * el instalador oficial de Fabric: pedirle a la API de Fabric el perfil de versión
 * ya armado (librerías + mainClass del loader) y guardarlo como un version.json
 * local con "inheritsFrom" apuntando a la versión vanilla. MCLC entiende ese
 * formato porque es el mismo que usa el launcher oficial de Mojang.
 */
async function resolveFabricVersion(mcVersion, instanceDir) {
  let loadersRes;
  try {
    loadersRes = await fetch(`${FABRIC_META}/${mcVersion}`);
  } catch (err) {
    throw new Error(`No se pudo conectar con la API de Fabric (¿internet caído o bloqueado?): ${err.message}`);
  }
  if (!loadersRes.ok) {
    throw new Error(`La API de Fabric respondió ${loadersRes.status} al buscar loaders para ${mcVersion}`);
  }
  const loaders = await loadersRes.json();
  if (!loaders?.length) throw new Error(`Fabric no tiene loader disponible para Minecraft ${mcVersion}`);

  const stable = loaders.find(l => l.loader.stable) || loaders[0];
  const loaderVersion = stable.loader.version;

  const profileRes = await fetch(`${FABRIC_META}/${mcVersion}/${loaderVersion}/profile/json`);
  if (!profileRes.ok) {
    throw new Error(`No se pudo descargar el perfil de Fabric ${loaderVersion} para ${mcVersion} (HTTP ${profileRes.status})`);
  }
  const profile = await profileRes.json();

  const customId = profile.id; // ej: "fabric-loader-0.15.11-1.21.1"
  const versionDir = path.join(instanceDir, 'versions', customId);
  fs.mkdirSync(versionDir, { recursive: true });
  fs.writeFileSync(path.join(versionDir, `${customId}.json`), JSON.stringify(profile, null, 2));

  return customId;
}

/**
 * Descarga los mods/recursos extra que el panel definió para esta instancia
 * (además de las librerías vanilla/forge/fabric, que minecraft-launcher-core
 * resuelve automáticamente).
 */
async function downloadInstanceFiles(instance, onProgress) {
  const instanceDir = path.join(INSTANCES_ROOT, instance.id);
  const modsDir = path.join(instanceDir, 'mods');
  fs.mkdirSync(modsDir, { recursive: true });

  if (!instance.mods || !instance.mods.length) return instanceDir;

  for (let i = 0; i < instance.mods.length; i++) {
    const mod = instance.mods[i];
    const dest = path.join(modsDir, mod.fileName);

    onProgress({
      percent: Math.round((i / instance.mods.length) * 60), // 0-60% = mods
      label: `Descargando ${mod.fileName}…`
    });

    if (fs.existsSync(dest)) continue; // ya está descargado, no lo repetimos

    const res = await fetch(mod.url);
    if (!res.ok) throw new Error(`No se pudo descargar ${mod.fileName}`);
    const buffer = await res.buffer();
    fs.writeFileSync(dest, buffer);
  }

  return instanceDir;
}

/**
 * Descarga (si hace falta) y lanza la instancia con la cuenta activa.
 */
async function launchInstance(instance, account, onProgress) {
  const instanceDir = await downloadInstanceFiles(instance, onProgress);

  onProgress({ percent: 62, label: 'Preparando Minecraft…' });

  // Resolvemos qué "versión" le vamos a pedir a minecraft-launcher-core.
  // - vanilla: el número tal cual (ej. "1.21.1")
  // - fabric: el perfil combinado que genera resolveFabricVersion (ej. "fabric-loader-0.15.11-1.21.1")
  // - forge: todavía requiere que subas vos el installer jar (ver README) — no está resuelto automáticamente.
  // Ojo con esto: minecraft-launcher-core busca `version.number` dentro del
  // version_manifest.json oficial de Mojang. Si le pasamos el id de fabric
  // (ej. "fabric-loader-0.15.11-1.21.1") ahí, nunca lo va a encontrar y tira
  // "Failed to find version ... in version_manifest.json" — que es justo el
  // punto donde se cancelaba la descarga después de "Instalando Fabric
  // Loader". La forma correcta es: `number` sigue siendo la versión vanilla
  // (para que MCLC la resuelva contra Mojang) y `custom` es el perfil de
  // fabric que ya generamos en resolveFabricVersion (el que trae el
  // "inheritsFrom" apuntando a esa vanilla).
  let fabricCustomId;
  if (instance.loader === 'fabric') {
    onProgress({ percent: 64, label: 'Instalando Fabric Loader…' });
    fabricCustomId = await resolveFabricVersion(instance.version, instanceDir);
  }

  // minecraft-launcher-core spawnea el ejecutable de java directo con
  // child_process.spawn, sin pasarle windowsHide. En Windows, "java.exe" es
  // un programa de consola, así que al lanzarlo desde una app sin consola
  // (Electron) Windows te abre una ventana de terminal de la nada. La forma
  // correcta de evitarlo es apuntar a "javaw.exe" en vez de "java.exe": es
  // el mismo binario pero sin la subsistema de consola, así que arranca
  // silencioso. Si la instancia trae su propio javaPath lo respetamos.
  const javaPath = instance.javaPath || (process.platform === 'win32' ? 'javaw' : 'java');

  const launcher = new Client();

  const authorization = account.type === 'microsoft'
    ? {
        access_token: account.accessToken,
        client_token: account.uuid,
        uuid: account.uuid,
        name: account.name,
        user_properties: '{}',
        meta: { type: 'msa' }
      }
    : {
        access_token: 'offline',
        client_token: account.uuid,
        uuid: account.uuid,
        name: account.name,
        user_properties: '{}',
        meta: { type: 'mojang', demo: false }
      };

  const opts = {
    authorization,
    root: instanceDir,
    javaPath,
    version: {
      number: instance.version,
      type: 'release',
      custom: fabricCustomId
    },
    forge: instance.loader === 'forge' ? instance.loaderInstallerPath : undefined,
    memory: {
      max: instance.memoryMax || '4G',
      min: instance.memoryMin || '2G'
    },
    // Por defecto minecraft-launcher-core solo usa 2 conexiones simultáneas para
    // bajar los cientos de archivitos de assets/librerías — por eso la primera
    // descarga se sentía eterna. Con más sockets en paralelo baja muchísimo el tiempo.
    overrides: {
      maxSockets: 16
    }
  };

  launcher.on('download-status', (data) => {
    // 65-100% = descarga de librerías/assets vanilla o del loader
    const percent = 65 + Math.round((data.current / data.total) * 35);
    onProgress({ percent, label: `Descargando archivos del juego…` });
  });

  // Antes esto quedaba vacío: si Minecraft crasheaba al arrancar (falta de Java,
  // versión mal escrita, etc.) el launcher no se enteraba de nada.
  launcher.on('data', (line) => console.log('[minecraft]', line));
  launcher.on('close', (code) => {
    if (code !== 0) console.error(`Minecraft se cerró con código ${code}`);
  });

  await launcher.launch(opts);
  onProgress({ percent: 100, label: 'Listo' });
  return launcher;
}

module.exports = { launchInstance, INSTANCES_ROOT };
